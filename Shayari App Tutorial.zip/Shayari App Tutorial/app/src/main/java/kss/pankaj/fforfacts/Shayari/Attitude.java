package kss.pankaj.fforfacts.Shayari;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import kss.pankaj.fforfacts.Adapter.ShayariAdapter;
import kss.pankaj.fforfacts.Model.ShayariModel;
import kss.pankaj.fforfacts.R;

public class Attitude extends AppCompatActivity {

    RecyclerView recyclerView;
    List<ShayariModel> list;
    ShayariAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attitude);

        recyclerView=findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);

        ShayariModel list1=new ShayariModel("इश्क़ है या कुछ और ये पता नहीं\n" +
                "पर जो तुमसे है किसी और से नहीं");
        ShayariModel list2=new ShayariModel("मै कैसे कहू की उसका साथ कैसा है\n" +
                "वो एक शख्स पुरे कायनात जैसा है");
        ShayariModel list3=new ShayariModel("तेरा होना ही मेरे लिये खास है\n" +
                "तू दूर ही सही मगर मेरे दिल के पास है");
        ShayariModel list4=new ShayariModel("मुझे तेरा साथ ज़िन्दगी भर नहीं चाहिये\n" +
                "बल्कि जब तक तू साथ है तबतक ज़िन्दगी चाहिए");
        ShayariModel list5=new ShayariModel("तुझसे मोहब्बत कुछ अलग सी है मेरी\n" +
                "तुझे खयालो में नहीं दुआओ में याद करते है");

        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        adapter=new ShayariAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);
    }
}