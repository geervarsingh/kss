package kss.pankaj.fforfacts.Shayari;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

import kss.pankaj.fforfacts.Adapter.CategoryAdapter;
import kss.pankaj.fforfacts.Adapter.ShayariAdapter;
import kss.pankaj.fforfacts.Model.ShayariModel;
import kss.pankaj.fforfacts.R;

public class Bewafa extends AppCompatActivity {

    RecyclerView recyclerView;
    List<ShayariModel> list;
    ShayariAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bewafa);

        recyclerView=findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        ShayariModel list1=new ShayariModel("Din hua hai to raat bhi hogi,\n" +
                "Ho mat udas kabhi to baat bhi hogi.\n" +
                "Itne pyar se dosti ki hai,\n" +
                "jindagi rahi to mulaqat bhi hogi..");

        ShayariModel list2=new ShayariModel("Ek Pehchan Hazaron Dost Bana Deti Hai\n" +
                "Ek Muskaan Hazaron Ghum Bhula Deti Hai");

        ShayariModel list3=new ShayariModel("Mil jati hai kitno ko khushi,\n" +
                "Mit jate hain kitno ke gum,\n" +
                "Message isliye bhejte hai hum,");

        ShayariModel list4=new ShayariModel("Na dil mein basakar bhulaya karte hain,\n" +
                "Na hasakar rulaya karte hain,\n" +
                "Kabhi mehsoos kar ke dekh lena,");

        ShayariModel list5=new ShayariModel("Din Ki Roshni Khwabon Ko Banane Mein Gujar Gayi,\n" +
                "Raat Ki Neend Bachche Ko Sulane Mein Gujar Gayi,");

        ShayariModel list6=new ShayariModel("Teri dhadkan hi zindagi ka kissa hai mera,\n" +
                "tu zindagi ka ek ahem hissa hai mera,");

        ShayariModel list7=new ShayariModel("Sukun apne dilka maine kho diya,\n" +
                "Khud ko tanhai ke samandar mai dubo diya,");

        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new ShayariAdapter(getApplicationContext(),list);
        recyclerView.setAdapter(adapter);

    }
}