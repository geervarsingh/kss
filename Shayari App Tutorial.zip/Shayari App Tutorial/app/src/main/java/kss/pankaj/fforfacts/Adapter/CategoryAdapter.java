package kss.pankaj.fforfacts.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import kss.pankaj.fforfacts.Model.CategoryModel;
import kss.pankaj.fforfacts.R;
import kss.pankaj.fforfacts.Shayari.Attitude;
import kss.pankaj.fforfacts.Shayari.Bewafa;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryHolder> {

    Context context;
    List<CategoryModel> list;

    public CategoryAdapter(Context context, List<CategoryModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CategoryHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryHolder holder, int position) {
        holder.imageView.setImageResource(list.get(position).getImage());
        holder.textView.setText(list.get(position).getName());
        holder.itemView.setOnClickListener(v -> {
//            Toast.makeText(context, ""+list.get(position).getName(), Toast.LENGTH_SHORT).show();
            switch (list.get(position).getName()){
                case "Bewafa" :{
                    Intent intent=new Intent(context, Bewafa.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }

                case "Attitude" :{
                    Intent intent=new Intent(context, Attitude.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class CategoryHolder extends RecyclerView.ViewHolder{
            ImageView imageView;
            TextView textView;
        public CategoryHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.category_image);
            textView=itemView.findViewById(R.id.category_name);
        }
    }
}
