package kss.pankaj.fforfacts.Adapter;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import kss.pankaj.fforfacts.Model.ShayariModel;
import kss.pankaj.fforfacts.R;

public class ShayariAdapter extends RecyclerView.Adapter<ShayariAdapter.ShayariHolder> {
    Context context;
    List<ShayariModel> shayariModelList;
    private int[] images;
    private  int imageIndex=0;


    public ShayariAdapter(Context context, List<ShayariModel> shayariModelList) {
        this.context = context;
        this.shayariModelList = shayariModelList;
    }

    @NonNull
    @Override
    public ShayariHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ShayariHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.shayari_item,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ShayariHolder holder, int position) {
        holder.textView.setText(shayariModelList.get(position).getShayari());
        holder.copy.setOnClickListener(v -> {
            ClipboardManager clipboardManager=(ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip=ClipData.newPlainText("label",shayariModelList.get(position).getShayari());
            assert  clipboardManager!=null;
            clipboardManager.setPrimaryClip(clip);
            Toast.makeText(context, "Shayari Copied", Toast.LENGTH_SHORT).show();
        });
        holder.shayariRl.setOnClickListener(v -> {
            int numofImages=10;
            images=new int [numofImages];
            images[0] =R.drawable.img1;
            images[1] =R.drawable.img2;
            images[2] =R.drawable.img3;
            images[3] =R.drawable.img4;
            images[4] =R.drawable.img5;
            images[5] =R.drawable.img6;
            images[6] =R.drawable.img7;
            images[7] =R.drawable.img8;
            images[8] =R.drawable.img9;
            images[9] =R.drawable.img10;
            holder.shayariRl.setBackgroundResource(images[imageIndex]);
            ++imageIndex;
            if (imageIndex==images.length-1)
                imageIndex=0;
        });



    }

    @Override
    public int getItemCount() {
        return shayariModelList.size();
    }

    class ShayariHolder extends RecyclerView.ViewHolder{
        TextView textView;
        ConstraintLayout copy;
        RelativeLayout shayariRl;
        public ShayariHolder(@NonNull View itemView) {
            super(itemView);
            textView=itemView.findViewById(R.id.shayari);
            copy=itemView.findViewById(R.id.copy);
            shayariRl=itemView.findViewById(R.id.shayari_rl);
        }
    }
}
