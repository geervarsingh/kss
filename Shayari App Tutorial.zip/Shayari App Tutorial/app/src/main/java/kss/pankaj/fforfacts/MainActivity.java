package kss.pankaj.fforfacts;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import kss.pankaj.fforfacts.Adapter.CategoryAdapter;
import kss.pankaj.fforfacts.Model.CategoryModel;

public class MainActivity extends AppCompatActivity {

    CategoryAdapter adapter;
    List<CategoryModel> list;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView=findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        CategoryModel list1=new CategoryModel("Bewafa",R.drawable.onesided);
        CategoryModel list2=new CategoryModel("Attitude",R.drawable.attitude);
        CategoryModel list3=new CategoryModel("Funny",R.drawable.funny);
        CategoryModel list4=new CategoryModel("Love",R.drawable.love);
        CategoryModel list5=new CategoryModel("Friendship",R.drawable.friendship);
        CategoryModel list6=new CategoryModel("Motivation",R.drawable.motivation);
        CategoryModel list7=new CategoryModel("Romantic",R.drawable.romantic);
        CategoryModel list8=new CategoryModel("FB Status",R.drawable.fbstatus);
        CategoryModel list9=new CategoryModel("Business",R.drawable.business);
        CategoryModel list10=new CategoryModel("Life",R.drawable.life);

        list.add(list1);
        list.add(list2);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        list.add(list8);
        list.add(list9);
        list.add(list10);
        adapter=new CategoryAdapter(this,list);
        recyclerView.setAdapter(adapter);
    }
}
