package bhobhli.love.attitudestatus.Adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import bhobhli.love.attitudestatus.Model.ShayariModel;
import bhobhli.love.attitudestatus.PlayAudio;
import bhobhli.love.attitudestatus.R;
import de.hdodenhof.circleimageview.CircleImageView;

public class ShayariAdapter extends RecyclerView.Adapter<ShayariAdapter.ShayariHolder> {
    Context context;
    List<ShayariModel> shayariModelList;

    public ShayariAdapter(Context context, List<ShayariModel> shayariModelList) {
        this.context = context;
        this.shayariModelList = shayariModelList;
    }


    @NonNull
    @Override
    public ShayariHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ShayariHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.shayari_item, parent, false));
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull ShayariHolder holder, int position) {
        holder.shayari.setText(" \" " + shayariModelList.get(position).getShayari() + " \" ");


        holder.editBtn.setOnClickListener(v -> {
            holder.editBtn.setVisibility(View.INVISIBLE);
            holder.closeEditBtn.setVisibility(View.VISIBLE);
            holder.linearLayout.setVisibility(View.VISIBLE);
        });

        holder.closeEditBtn.setOnClickListener(v -> {
            holder.editBtn.setVisibility(View.VISIBLE);

            holder.closeEditBtn.setVisibility(View.INVISIBLE);
            holder.linearLayout.setVisibility(View.INVISIBLE);

            holder.fonts_layout.setVisibility(View.INVISIBLE);
            holder.text_color_layout.setVisibility(View.INVISIBLE);
            holder.text_size_layout.setVisibility(View.INVISIBLE);
            holder.bg_color_layout.setVisibility(View.INVISIBLE);

        });

        /////////////////background colors/////////////
        holder.background.setOnClickListener(v -> {
            holder.bg_color_layout.setVisibility(View.VISIBLE);

            holder.background.setBackgroundColor(R.color.colorPrimaryDark);
            holder.backgroundTitle.setTextColor(Color.WHITE);

            holder.fonts.setBackgroundColor(View.GONE);
            holder.fontsTitle.setTextColor(Color.WHITE);

            holder.add_text_color.setBackgroundColor(View.GONE);
            holder.textColorTitle.setTextColor(Color.WHITE);

            holder.add_textsize.setBackgroundColor(View.GONE);
            holder.textColorTitle.setTextColor(Color.WHITE);

            /////////////all Text layout/////////////
            holder.text_size_layout.setVisibility(View.INVISIBLE);
            holder.text_color_layout.setVisibility(View.INVISIBLE);
            holder.fonts_layout.setVisibility(View.INVISIBLE);


            holder.bg_default.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.TRANSPARENT);
            });
            holder.bg_red.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.RED);
            });
            holder.bg_blue.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.BLUE);
            });
            holder.bg_green.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.GREEN);
            });
            holder.bg_black.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.BLACK);
            });
            holder.bg_white.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.WHITE);
            });
            holder.bg_yellow.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.YELLOW);
            });
            holder.bg_silver.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.GRAY);
            });
            holder.bg_magenta.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.MAGENTA);
            });
            holder.bg_cyan.setOnClickListener(view -> {
                holder.shayari.setBackgroundColor(Color.CYAN);
            });

        });
        ////////////////////////////////
        ///////////////////////////////////
        ///////////////////////////////////

        //////////Fonts////////
        holder.fonts.setOnClickListener(v -> {
            holder.fonts_layout.setVisibility(View.VISIBLE);
            holder.text_color_layout.setVisibility(View.INVISIBLE);
            holder.text_size_layout.setVisibility(View.INVISIBLE);
            holder.bg_color_layout.setVisibility(View.INVISIBLE);

            holder.fonts.setBackgroundColor(R.color.colorPrimaryDark);
            holder.fontsTitle.setTextColor(Color.WHITE);

            holder.add_textsize.setBackgroundColor(View.GONE);
            holder.textSizeTitle.setTextColor(Color.WHITE);
            holder.add_text_color.setBackgroundColor(View.GONE);
            holder.textColorTitle.setTextColor(Color.WHITE);
            holder.background.setBackgroundColor(View.GONE);
            holder.backgroundTitle.setTextColor(Color.WHITE);
            ////////background image/////


            /////////Add Fonts Java Code///////////////////
            /////////Add Fonts Java Code///////////////////


            holder.batik.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "batik.otf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.black_widow.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "black_widow.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.heleny.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "heleny.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.lemon.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "lemon.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.pinky.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "pinky.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.resote.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "resote.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });


            holder.default_font.setOnClickListener(v1 -> {
                try {
                    Typeface typeface = Typeface.DEFAULT;
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.alloy.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "alloy.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.bigfat.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "bigfat.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.chrusty.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "chrusty.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.branda.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "branda.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.freedom.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "freedom.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.gingies.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "gingies.otf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.plastic.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "plastic.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.quite.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "quite.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.tothepoint.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "tothepoint.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });
            holder.vampire.setOnClickListener(v2 -> {
                try {
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), "vampire.ttf");
                    holder.shayari.setTypeface(typeface);
                } catch (Exception e) {
                }

            });

        });

        //////////Text Colors////////
        holder.add_text_color.setOnClickListener(v -> {

            holder.text_color_layout.setVisibility(View.VISIBLE);
            holder.fonts_layout.setVisibility(View.INVISIBLE);
            holder.text_size_layout.setVisibility(View.INVISIBLE);
            holder.bg_color_layout.setVisibility(View.INVISIBLE);

            holder.add_text_color.setBackgroundColor(R.color.colorPrimaryDark);
            holder.textColorTitle.setTextColor(Color.WHITE);

            holder.fonts.setBackgroundColor(View.GONE);
            holder.fontsTitle.setTextColor(Color.WHITE);
            holder.add_textsize.setBackgroundColor(View.GONE);
            holder.textSizeTitle.setTextColor(Color.WHITE);
            holder.background.setBackgroundColor(View.GONE);
            holder.backgroundTitle.setTextColor(Color.WHITE);


            holder.red.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.RED);
                } catch (Exception e) {
                }

            });
            holder.blue.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.BLUE);
                } catch (Exception e) {
                }

            });
            holder.green.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.GREEN);
                } catch (Exception e) {
                }

            });
            holder.black.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.BLACK);
                } catch (Exception e) {
                }

            });
            holder.white.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.WHITE);
                } catch (Exception e) {
                }

            });
            holder.yellow.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.YELLOW);
                } catch (Exception e) {
                }

            });
            holder.silver.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.GRAY);
                } catch (Exception e) {
                }

            });
            holder.magenta.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.MAGENTA);
                } catch (Exception e) {
                }

            });
            holder.cyan.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextColor(Color.CYAN);
                } catch (Exception e) {
                }

            });


        });

        /////////////Text size////////////
        holder.add_textsize.setOnClickListener(v -> {
            holder.text_size_layout.setVisibility(View.VISIBLE);
            holder.text_color_layout.setVisibility(View.INVISIBLE);
            holder.fonts_layout.setVisibility(View.INVISIBLE);
            holder.bg_color_layout.setVisibility(View.INVISIBLE);

            holder.add_textsize.setBackgroundColor(R.color.colorPrimaryDark);
            holder.textColorTitle.setTextColor(Color.WHITE);

            holder.fonts.setBackgroundColor(View.GONE);
            holder.fontsTitle.setTextColor(Color.WHITE);
            holder.add_text_color.setBackgroundColor(View.GONE);
            holder.textColorTitle.setTextColor(Color.WHITE);
            holder.background.setBackgroundColor(View.GONE);
            holder.backgroundTitle.setTextColor(Color.WHITE);

            /////////Add Text Size Java Code///////////////////
            /////////Add Text Size Java Code///////////////////


            holder.fifteen.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(15);
                } catch (Exception e) {
                }

            });
            holder.seventeen.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(17);
                } catch (Exception e) {
                }

            });
            holder.nineteen.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(19);
                } catch (Exception e) {
                }

            });
            holder.twentyone.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(21);
                } catch (Exception e) {
                }

            });
            holder.twentythree.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(23);
                } catch (Exception e) {
                }

            });
            holder.twentyfive.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(25);
                } catch (Exception e) {
                }

            });
            holder.twentyseven.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(27);
                } catch (Exception e) {
                }

            });
            holder.twentynine.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(29);
                } catch (Exception e) {
                }

            });
            holder.thirtyone.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(31);
                } catch (Exception e) {
                }

            });
            holder.thirtythree.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(33);
                } catch (Exception e) {
                }

            });
            holder.thirtyfive.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(35);
                } catch (Exception e) {
                }

            });
            holder.fourty.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(40);
                } catch (Exception e) {
                }

            });
            holder.fifty.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(50);
                } catch (Exception e) {
                }

            });
            holder.fiftyfive.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(55);
                } catch (Exception e) {
                }

            });
            holder.sixty.setOnClickListener(view -> {
                try {
                    holder.shayari.setTextSize(60);
                } catch (Exception e) {
                }

            });

        });
        /////////Play Button/////////////
        holder.playBtn.setOnClickListener(v -> {
            Toast.makeText(context, "Please wait.", Toast.LENGTH_SHORT).show();
            PlayAudio playAudio = new PlayAudio((Activity) context, shayariModelList.get(position).getShayari());
        });

        //////share direct whatsapp button/////
        holder.whatsappBtn.setOnClickListener(v -> {
            ////kis layout ko save karna hai////
            Bitmap image = getBitmapFromView(holder.screenshot);
            ////kisme save karna hai////
            holder.capture_screenshot.setImageBitmap(image);
            ///this is very important for share the image///
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());

            File f = new File(context.getExternalCacheDir() + "/" + context.getString(R.string.app_name) + shayariModelList.get(position) + ".png");
            Intent intent;
            FileOutputStream outputStream = null;
            try {
                outputStream = new FileOutputStream(f);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            BitmapDrawable drawable = (BitmapDrawable) holder.capture_screenshot.getDrawable();
            Bitmap bitmap = drawable.getBitmap();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            try {
                outputStream.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            ////share the image//////
            try {
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");
                intent.setPackage("com.whatsapp");
                intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
            }
        });

        //////share direct all button/////
        holder.shareBtn.setOnClickListener(v -> {
            ////kis layout ko save karna hai////
            Bitmap image = getBitmapFromView(holder.screenshot);
            ////kisme save karna hai////
            holder.capture_screenshot.setImageBitmap(image);
            ///this is very important for share the image///
            StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
            StrictMode.setVmPolicy(builder.build());

            File f = new File(context.getExternalCacheDir() + "/" + context.getString(R.string.app_name) + shayariModelList.get(position) + ".png");
            Intent intent;
            FileOutputStream outputStream = null;
            try {
                outputStream = new FileOutputStream(f);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            BitmapDrawable drawable = (BitmapDrawable) holder.capture_screenshot.getDrawable();
            Bitmap bitmap = drawable.getBitmap();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);
            try {
                outputStream.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            ////share the image//////
            try {
                intent = new Intent(Intent.ACTION_SEND);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(f));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            } catch (Exception e) {
            }
        });

    }

    @Override
    public int getItemCount() {
        return shayariModelList.size();
    }


    class ShayariHolder extends RecyclerView.ViewHolder {
        CardView whatsappBtn, shareBtn, playBtn;
        ImageView capture_screenshot;
        TextView text_title, backgroundText;
        TextView iconText;
        CircleImageView editBtn, closeEditBtn;
        Uri imageUri;

        ConstraintLayout text, fonts_layout, text_color_layout, text_size_layout;
        ConstraintLayout bg_images_layout, image;
        ConstraintLayout bg_color_layout;
        LinearLayout linearLayout;

        CardView alloy, bigfat, branda, chrusty, freedom, gingies, plastic, quite, tothepoint, vampire,
                batik, black_widow, heleny, lemon, pinky, resote;
        //////////////Txt Colors//////////
        CardView red, blue, green, black, white, yellow, silver, magenta, cyan;
        /////////////Text size/////////
        TextView fifteen, seventeen, nineteen, twentyone, twentythree, twentyfive, twentyseven, twentynine, thirtyone, thirtythree, thirtyfive, fourty, fifty, fiftyfive, sixty;
        CardView default_font;
        ////////////Background Color//////////
        CardView bg_red, bg_blue, bg_green, bg_black, bg_white, bg_yellow, bg_silver, bg_magenta, bg_cyan, bg_default;
        CircleImageView bg_color_all;
        ConstraintLayout screenshot;
        ////////Background Image//////////

        TextView shayari;
        ////////
        ConstraintLayout add_text_color, add_textsize, background, fonts;
        TextView fontsTitle, textColorTitle, backgroundTitle, textSizeTitle;

        public ShayariHolder(@NonNull View itemView) {
            super(itemView);

            /////////Share Button variable///////
            whatsappBtn = itemView.findViewById(R.id.whatsappBtn);
            shareBtn = itemView.findViewById(R.id.shareBtn);
            playBtn = itemView.findViewById(R.id.playBtn);
            capture_screenshot = itemView.findViewById(R.id.capture_screenshot);


            /////////TextView text title///////////
            fontsTitle = itemView.findViewById(R.id.fontsTitle);
            textColorTitle = itemView.findViewById(R.id.textColorTitle);
            backgroundTitle = itemView.findViewById(R.id.backgroundTitle);
            textSizeTitle = itemView.findViewById(R.id.textSizeTitle);
            //////////Background Color Variable/////////////////
            screenshot = itemView.findViewById(R.id.layout_screenshot);
            bg_red = itemView.findViewById(R.id.bg_red);
            bg_blue = itemView.findViewById(R.id.bg_blue);
            bg_green = itemView.findViewById(R.id.bg_green);
            bg_black = itemView.findViewById(R.id.bg_black);
            bg_white = itemView.findViewById(R.id.bg_white);
            bg_yellow = itemView.findViewById(R.id.bg_yellow);
            bg_silver = itemView.findViewById(R.id.bg_silver);
            bg_magenta = itemView.findViewById(R.id.bg_magenta);
            bg_cyan = itemView.findViewById(R.id.bg_cyan);
            bg_default = itemView.findViewById(R.id.bg_default);

            ///////Text Size Variable/////////
            fifteen = itemView.findViewById(R.id.fifteen);
            seventeen = itemView.findViewById(R.id.seventeen);
            nineteen = itemView.findViewById(R.id.nineteen);
            twentyone = itemView.findViewById(R.id.twentyone);
            twentythree = itemView.findViewById(R.id.twentythree);
            twentyfive = itemView.findViewById(R.id.twentyfive);
            twentyseven = itemView.findViewById(R.id.twentyseven);
            twentynine = itemView.findViewById(R.id.twentynine);
            thirtyone = itemView.findViewById(R.id.thirtyone);
            thirtythree = itemView.findViewById(R.id.thirtythree);
            thirtyfive = itemView.findViewById(R.id.thirtyfive);
            fourty = itemView.findViewById(R.id.fourty);
            fifty = itemView.findViewById(R.id.fifty);
            fiftyfive = itemView.findViewById(R.id.fiftyfive);
            sixty = itemView.findViewById(R.id.sixty);

            //////////////Text Colors variable ///////////////
            red = itemView.findViewById(R.id.red);
            blue = itemView.findViewById(R.id.blue);
            green = itemView.findViewById(R.id.green);
            black = itemView.findViewById(R.id.black);
            white = itemView.findViewById(R.id.white);
            yellow = itemView.findViewById(R.id.yellow);
            silver = itemView.findViewById(R.id.silver);
            magenta = itemView.findViewById(R.id.magenta);
            cyan = itemView.findViewById(R.id.cyan);

            shayari = itemView.findViewById(R.id.shayari);
            editBtn = itemView.findViewById(R.id.editBtn);
            closeEditBtn = itemView.findViewById(R.id.closeEditBtn);
            linearLayout = itemView.findViewById(R.id.constraintLayout2);

            ////////////TExttview///////////
//            fonts=itemView.findViewById(R.id.add_font_textview);
            fonts_layout = itemView.findViewById(R.id.fonts_layout);
            text_color_layout = itemView.findViewById(R.id.text_color_layout);
            text_size_layout = itemView.findViewById(R.id.text_size_layout);

            //////////bg images///////////

            image = itemView.findViewById(R.id.image);

            ///////////bg colors//////////////


            ///////////Text/////////
            fonts = itemView.findViewById(R.id.fonts);
            add_text_color = itemView.findViewById(R.id.add_text_color_textview);
            add_textsize = itemView.findViewById(R.id.add_textsize_textview);
            background = itemView.findViewById(R.id.background);

            bg_color_layout = itemView.findViewById(R.id.bg_color_layout);


            batik = itemView.findViewById(R.id.font_batik);
            alloy = itemView.findViewById(R.id.font_alloyink);
            bigfat = itemView.findViewById(R.id.font_bigfat);
            branda = itemView.findViewById(R.id.font_branda);
            chrusty = itemView.findViewById(R.id.font_chrusty);
            freedom = itemView.findViewById(R.id.font_freedom);
            gingies = itemView.findViewById(R.id.font_gingies);
            plastic = itemView.findViewById(R.id.font_plastic);
            quite = itemView.findViewById(R.id.font_quite);
            tothepoint = itemView.findViewById(R.id.font_tothepoint);
            vampire = itemView.findViewById(R.id.font_vampire);
            black_widow = itemView.findViewById(R.id.font_black_widow);
            heleny = itemView.findViewById(R.id.font_heleny);
            lemon = itemView.findViewById(R.id.font_lemon);
            pinky = itemView.findViewById(R.id.font_pinky);
            resote = itemView.findViewById(R.id.font_resote);
            default_font = itemView.findViewById(R.id.default_font);
            ////////Textview///////
            shayari = itemView.findViewById(R.id.shayari);


        }

    }

    ///important for save the image/////
    private Bitmap getBitmapFromView(View view) {
        Bitmap returnedBitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(returnedBitmap);
        Drawable bgDrawable = view.getBackground();
        if (bgDrawable != null) {
            bgDrawable.draw(canvas);
        } else {
            canvas.drawColor(Color.BLACK);
        }
        view.draw(canvas);
        return returnedBitmap;
    }


}
