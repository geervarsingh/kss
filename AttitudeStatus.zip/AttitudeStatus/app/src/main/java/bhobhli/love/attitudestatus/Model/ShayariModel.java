package bhobhli.love.attitudestatus.Model;

public class ShayariModel {
    String shayari;

    public ShayariModel() {
    }

    public ShayariModel(String shayari) {
        this.shayari = shayari;
    }

    public String getShayari() {
        return shayari;
    }

    public void setShayari(String shayari) {
        this.shayari = shayari;
    }
}
