package bhobhli.love.attitudestatus;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.messaging.FirebaseMessaging;

public class HomeActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);



        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_gallery)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id=item.getItemId();
        if (id== R.id.rate_us){
            Uri uri= Uri.parse(("https://play.google.com/store/apps/details?id="+getApplicationContext().getPackageName()));
            Intent intent=new Intent(Intent.ACTION_VIEW,uri);
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Unable to Open"+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        if (id== R.id.other_app){
            Uri uri= Uri.parse(("https://play.google.com/store/apps/developer?id=Geervar+Singh"));
            Intent intent=new Intent(Intent.ACTION_VIEW,uri);
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Unable to Open"+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        if (id== R.id.check_update){
            Uri uri= Uri.parse(("https://play.google.com/store/apps/details?id="+getApplicationContext().getPackageName()));
            Intent intent=new Intent(Intent.ACTION_VIEW,uri);
            try {
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "Unable to Open"+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        else if (id== R.id.share_app){
            try {
                Intent intent=new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                String sharebody="Read, Listen And Share Daily New Shayaries & Status Go for Download App Now and Join us:- https://play.google.com/store/apps/details?id=bhobhli.love.totalshayaricollection";

                String sharesub="Attitude Status";
                intent.putExtra(Intent.EXTRA_SUBJECT,sharesub);
                intent.putExtra(Intent.EXTRA_TEXT,sharebody);
                startActivity(Intent.createChooser(intent,"Share App"));
            }
            catch (Exception e){
            }
        }
        return false;
    }


    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }
}