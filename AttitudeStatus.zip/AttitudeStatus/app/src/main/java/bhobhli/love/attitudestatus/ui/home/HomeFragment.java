package bhobhli.love.attitudestatus.ui.home;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.messaging.FirebaseMessaging;

import java.util.ArrayList;
import java.util.List;

import bhobhli.love.attitudestatus.Adapter.CategoryAdapter;
import bhobhli.love.attitudestatus.Model.CategoryModel;
import bhobhli.love.attitudestatus.R;

public class HomeFragment extends Fragment {

    FirebaseFirestore firestore;
    CategoryAdapter adapter;
    List<CategoryModel> list;
    RecyclerView recyclerView;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel =
                    new NotificationChannel("notification", "notification", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getContext().getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        FirebaseMessaging.getInstance().subscribeToTopic("all")
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        String msg = "Done";
                        if (!task.isSuccessful()) {
                            msg = "Failed";
                        }
                    }
                });
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        firestore=FirebaseFirestore.getInstance();
        recyclerView=root.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        list=new ArrayList<>();
        recyclerView.setHasFixedSize(true);
        CategoryModel list0=new CategoryModel("Attitude", R.drawable.attitude);
        CategoryModel list2=new CategoryModel("Funny", R.drawable.funny);
        CategoryModel list1=new CategoryModel("Love", R.drawable.love);
        CategoryModel list3=new CategoryModel("Friendship", R.drawable.friendship);
        CategoryModel list4=new CategoryModel("Motivation", R.drawable.motivation);
        CategoryModel list5=new CategoryModel("Romantic", R.drawable.romantic);
        CategoryModel list6=new CategoryModel("Business", R.drawable.business);
        CategoryModel list7=new CategoryModel("Life", R.drawable.life);
        list.add(list0);
        list.add(list2);
        list.add(list1);
        list.add(list3);
        list.add(list4);
        list.add(list5);
        list.add(list6);
        list.add(list7);
        adapter=new CategoryAdapter(getContext(),list);
        recyclerView.setAdapter(adapter);
        return root;
    }

}