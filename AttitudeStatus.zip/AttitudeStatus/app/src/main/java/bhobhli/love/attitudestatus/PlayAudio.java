package bhobhli.love.attitudestatus;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.DialogInterface;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;

import androidx.appcompat.app.AlertDialog;

import java.util.Locale;


public class PlayAudio extends HomeActivity {

    Activity activity;
    AlertDialog alertDialog;
    TextToSpeech t1;
    String txt;


    @SuppressLint("SetTextI18n")
    public PlayAudio(final Activity activity, final String txt) {

        this.activity = activity;
        this.txt = txt;

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        final View view = LayoutInflater.from(activity).inflate(R.layout.playaudiolayout, null);

        builder.setView(view);
        builder.setCancelable(true);
        alertDialog = builder.create();
        t1 = new TextToSpeech(activity.getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status != TextToSpeech.ERROR) {

                    t1.setLanguage(new Locale("hin"));
                    t1.speak(txt, TextToSpeech.QUEUE_FLUSH, null);
                    view.findViewById(R.id.playaudioBtn).setVisibility(View.GONE);
                    view.findViewById(R.id.pauseaudioBtn).setVisibility(View.VISIBLE);
                }

            }

        });

        view.findViewById(R.id.playaudioBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.findViewById(R.id.playaudioBtn).setVisibility(View.GONE);
                view.findViewById(R.id.pauseaudioBtn).setVisibility(View.VISIBLE);

                t1.speak(txt, TextToSpeech.QUEUE_FLUSH, null);
            }
        });
        view.findViewById(R.id.pauseaudioBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                view.findViewById(R.id.playaudioBtn).setVisibility(View.VISIBLE);
                view.findViewById(R.id.pauseaudioBtn).setVisibility(View.GONE);
                if (t1 != null) {
                    t1.stop();

                }
            }
        });


        view.findViewById(R.id.audioCancel).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (t1 != null) {
                    t1.stop();
                    t1.shutdown();
                }

                dismissDialog();

            }
        });

        builder.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                if (t1 != null) {
                    t1.stop();
                    t1.shutdown();
                }
            }
        });

    }

    public void startDialog() {
        alertDialog.show();
    }

    public void dismissDialog() {
        alertDialog.dismiss();
    }

}
