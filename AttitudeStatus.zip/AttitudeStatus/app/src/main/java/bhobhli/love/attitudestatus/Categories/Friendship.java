package bhobhli.love.attitudestatus.Categories;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import bhobhli.love.attitudestatus.Adapter.ShayariAdapter;
import bhobhli.love.attitudestatus.Model.ShayariModel;
import bhobhli.love.attitudestatus.R;

public class Friendship extends AppCompatActivity {
    TextView shayari;
    FirebaseFirestore firestore;
    ShayariAdapter adapter;
    List<ShayariModel> shayariModelList;
    RecyclerView recyclerView;
    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shayari);
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Friendship");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        shayari=findViewById(R.id.shayari);
        firestore= FirebaseFirestore.getInstance();
        recyclerView=findViewById(R.id.recyclerview);
        progressBar=findViewById(R.id.progress);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        shayariModelList=new ArrayList<>();
        adapter=new ShayariAdapter(Friendship.this,shayariModelList);
        recyclerView.setAdapter(adapter);


        firestore.collection("Friendship")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        TextView textView;
                        textView=findViewById(R.id.shayariCounter);
                        long cont=task.getResult().size();
                        String s=String.valueOf(cont);
                        textView.setText("Total : "+s);
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                ShayariModel shayariModel=document.toObject(ShayariModel.class);
                                shayariModelList.add(shayariModel);
                                adapter.notifyDataSetChanged();
                                progressBar.setVisibility(View.GONE);

                            }
                        } else {
                            Toast.makeText(Friendship.this, "Error:"+task.getException(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);

                        }
                    }
                });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
