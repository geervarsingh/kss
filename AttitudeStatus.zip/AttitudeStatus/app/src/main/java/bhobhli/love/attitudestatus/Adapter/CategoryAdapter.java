package bhobhli.love.attitudestatus.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import bhobhli.love.attitudestatus.Categories.Attitude;
import bhobhli.love.attitudestatus.Categories.Business;
import bhobhli.love.attitudestatus.Categories.Friendship;
import bhobhli.love.attitudestatus.Categories.Funny;
import bhobhli.love.attitudestatus.Categories.Life;
import bhobhli.love.attitudestatus.Categories.Love;
import bhobhli.love.attitudestatus.Categories.Motivation;
import bhobhli.love.attitudestatus.Categories.Romantic;
import bhobhli.love.attitudestatus.Model.CategoryModel;
import bhobhli.love.attitudestatus.R;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryHolder> {
    Context context;
    List<CategoryModel> list;

    public CategoryAdapter(Context context, List<CategoryModel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public CategoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CategoryHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryHolder holder, int position) {
        holder.imageView.setImageResource(list.get(position).getImage());
        holder.textView.setText(list.get(position).getName());

        holder.itemView.setOnClickListener(v -> {
            switch (list.get(position).getName()) {

                case "Attitude": {
                    Intent intent = new Intent(context, Attitude.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Funny": {
                    Intent intent = new Intent(context, Funny.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Love": {
                    Intent intent = new Intent(context, Love.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Friendship": {
                    Intent intent = new Intent(context, Friendship.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Motivation": {
                    Intent intent = new Intent(context, Motivation.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Romantic": {
                    Intent intent = new Intent(context, Romantic.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Business": {
                    Intent intent = new Intent(context, Business.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
                case "Life": {
                    Intent intent = new Intent(context, Life.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                }
            }

        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class CategoryHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;

        public CategoryHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id
                    .category_image);
            textView = itemView.findViewById(R.id.category_name);

        }
    }
}
